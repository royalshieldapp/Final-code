package royalshield.v2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import royalshield.v2.ui.theme.Royal_shieldTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Royal_shieldTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    RoyalShieldScreen()
                }
            }
        }
    }
}

data class RoyalShieldUiState(
    val alarmArmed: Boolean = false,
    val nightModeEnabled: Boolean = false,
    val camerasOnline: Boolean = true,
    val escortRequests: Int = 0,
    val emergencyTriggered: Boolean = false,
    val locationShared: Boolean = false,
    val lastAction: String = "Sin eventos recientes"
)

fun toggleAlarm(current: RoyalShieldUiState): RoyalShieldUiState {
    val nextArmed = !current.alarmArmed
    val action = if (nextArmed) "Alarma perimetral activada" else "Alarma perimetral desactivada"
    return current.copy(alarmArmed = nextArmed, lastAction = action)
}

fun toggleNightMode(current: RoyalShieldUiState): RoyalShieldUiState {
    val nightEnabled = !current.nightModeEnabled
    val action = if (nightEnabled) "Modo nocturno habilitado" else "Modo nocturno deshabilitado"
    return current.copy(nightModeEnabled = nightEnabled, lastAction = action)
}

fun toggleCameras(current: RoyalShieldUiState): RoyalShieldUiState {
    val cameras = !current.camerasOnline
    val action = if (cameras) "Cámaras en línea" else "Cámaras fuera de servicio"
    return current.copy(camerasOnline = cameras, lastAction = action)
}

fun requestEmergencySupport(current: RoyalShieldUiState): RoyalShieldUiState {
    return current.copy(
        emergencyTriggered = true,
        lastAction = "Botón de pánico presionado"
    )
}

fun scheduleEscort(current: RoyalShieldUiState): RoyalShieldUiState {
    val newCount = current.escortRequests + 1
    return current.copy(
        escortRequests = newCount,
        lastAction = "Acompañamiento programado #$newCount"
    )
}

fun shareTrustedLocation(current: RoyalShieldUiState): RoyalShieldUiState {
    return current.copy(
        locationShared = true,
        lastAction = "Ubicación compartida con el círculo seguro"
    )
}

@Composable
fun RoyalShieldScreen(modifier: Modifier = Modifier) {
    var uiState by rememberSaveable { mutableStateOf(RoyalShieldUiState()) }
    val gradient = Brush.verticalGradient(
        listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
            MaterialTheme.colorScheme.surface
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(gradient)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 36.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            RoyalShieldHeader(uiState)

            StatusCard(uiState)

            val actions = listOf(
                SecurityAction(
                    emoji = "🛡️",
                    title = if (uiState.alarmArmed) "Alarma activa" else "Activar alarma",
                    description = if (uiState.alarmArmed) "Todo el perímetro está protegido" else "Arma la red completa",
                    onClick = { uiState = toggleAlarm(uiState) }
                ),
                SecurityAction(
                    emoji = "🌙",
                    title = if (uiState.nightModeEnabled) "Modo noche" else "Modo noche",
                    description = if (uiState.nightModeEnabled) "Rutina nocturna automatizada" else "Atenúa luces y sensores",
                    onClick = { uiState = toggleNightMode(uiState) }
                ),
                SecurityAction(
                    emoji = "📹",
                    title = if (uiState.camerasOnline) "Cámaras en vivo" else "Reactivar cámaras",
                    description = if (uiState.camerasOnline) "Monitoreo transmitiendo" else "Vuelve a habilitar transmisión",
                    onClick = { uiState = toggleCameras(uiState) }
                ),
                SecurityAction(
                    emoji = "🚓",
                    title = "Pedir patrulla",
                    description = "Solicita acompañamiento preventivo",
                    onClick = { uiState = scheduleEscort(uiState) }
                )
            )

            ActionsGrid(actions = actions)

            EmergencyCard(
                lastAction = uiState.lastAction,
                emergencyTriggered = uiState.emergencyTriggered,
                locationShared = uiState.locationShared,
                escortRequests = uiState.escortRequests,
                onEmergency = { uiState = requestEmergencySupport(uiState) },
                onShareLocation = { uiState = shareTrustedLocation(uiState) }
            )
        }
    }
}

data class SecurityAction(
    val emoji: String,
    val title: String,
    val description: String,
    val onClick: () -> Unit
)

@Composable
fun RoyalShieldHeader(uiState: RoyalShieldUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Royal Shield",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimary
        )
        Text(
            text = if (uiState.alarmArmed) "Protección activa" else "Sistema en espera",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
        )
    }
}

@Composable
fun StatusCard(uiState: RoyalShieldUiState, modifier: Modifier = Modifier) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
        )
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Estado general",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                StatusBadge(
                    title = if (uiState.alarmArmed) "Armad" else "Desarmado",
                    value = if (uiState.alarmArmed) "Perímetro protegido" else "Listo para activar"
                )
                StatusBadge(
                    title = if (uiState.camerasOnline) "Cámaras" else "Sin cámaras",
                    value = if (uiState.camerasOnline) "Monitoreo en vivo" else "Revisa conexión"
                )
            }
            Text(
                text = uiState.lastAction,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun StatusBadge(title: String, value: String) {
    Column(
        modifier = Modifier.widthIn(min = 120.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun ActionsGrid(actions: List<SecurityAction>) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        actions.chunked(2).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                row.forEach { action ->
                    RoyalShieldActionCard(
                        action = action,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (row.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun RoyalShieldActionCard(action: SecurityAction, modifier: Modifier = Modifier) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        onClick = action.onClick
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(text = action.emoji, fontSize = 28.sp)
            Text(
                text = action.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = action.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun EmergencyCard(
    lastAction: String,
    emergencyTriggered: Boolean,
    locationShared: Boolean,
    escortRequests: Int,
    onEmergency: () -> Unit,
    onShareLocation: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Centro de emergencias",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (emergencyTriggered) "Alerta enviada al equipo" else "Listo para responder al instante",
                style = MaterialTheme.typography.bodyMedium
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onEmergency,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = if (emergencyTriggered) "Reforzar alerta" else "Botón de pánico")
                }
                OutlinedButton(
                    onClick = onShareLocation,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = if (locationShared) "Ubicación enviada" else "Compartir ubicación")
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Acompañamientos: $escortRequests",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = lastAction,
                    textAlign = TextAlign.End,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Preview(showSystemUi = true)
@Composable
fun RoyalShieldPreview() {
    Royal_shieldTheme {
        RoyalShieldScreen()
    }
}