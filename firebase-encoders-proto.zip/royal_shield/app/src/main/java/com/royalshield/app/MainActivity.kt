package com.royalshield.app

import android.os.Bundle
import android.os.Parcelable
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.royalshield.app.ui.theme.Royal_shieldTheme
import kotlinx.parcelize.Parcelize

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Royal_shieldTheme {
                RoyalShieldApp()
            }
        }
    }
}

enum class RoyalShieldDestination(val label: String, val emoji: String) {
    Dashboard("Panel", "🏠"),
    Subscription("Elite", "💳"),
    Registration("Registro", "🔐")
}

@Composable
fun RoyalShieldApp() {
    var destination by rememberSaveable { mutableStateOf(RoyalShieldDestination.Dashboard) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                RoyalShieldDestination.values().forEach { item ->
                    NavigationBarItem(
                        selected = destination == item,
                        onClick = { destination = item },
                        icon = { Text(text = item.emoji, fontSize = 20.sp) },
                        label = { Text(text = item.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        val contentModifier = Modifier.padding(innerPadding)
        when (destination) {
            RoyalShieldDestination.Dashboard -> RoyalShieldScreen(modifier = contentModifier)
            RoyalShieldDestination.Subscription -> SubscriptionScreen(modifier = contentModifier)
            RoyalShieldDestination.Registration -> RegistrationScreen(modifier = contentModifier)
        }
    }
}

@Parcelize
data class RoyalShieldUiState(
    val alarmArmed: Boolean = false,
    val nightModeEnabled: Boolean = false,
    val camerasOnline: Boolean = true,
    val escortRequests: Int = 0,
    val emergencyTriggered: Boolean = false,
    val locationShared: Boolean = false,
    val urlThreatsBlocked: Int = 0,
    val dataBreachMonitoring: Boolean = false,
    val malwareScanRunning: Boolean = false,
    val soundDetectionEnabled: Boolean = false,
    val lowBatteryProtocolEnabled: Boolean = false,
    val fakePinEnabled: Boolean = false,
    val voiceAssistantListening: Boolean = false,
    val autoRecordingEnabled: Boolean = false,
    val safePathMonitoring: Boolean = false,
    val lastAction: String = "Sin eventos recientes"
) : Parcelable

fun toggleAlarm(current: RoyalShieldUiState): RoyalShieldUiState {
    val nextArmed = !current.alarmArmed
    val action = if (nextArmed) "Alarma perimetral activada" else "Alarma perimetral desactivada"
    return current.copy(alarmArmed = nextArmed, lastAction = action)
}

fun toggleNightMode(current: RoyalShieldUiState): RoyalShieldUiState {
    val nightEnabled = !current.nightModeEnabled
    val action = if (nightEnabled) "Modo nocturno habilitado" else "Modo nocturno deshabilitado"
    return current.copy(nightModeEnabled = nightEnabled, lastAction = action)
}

fun toggleCameras(current: RoyalShieldUiState): RoyalShieldUiState {
    val cameras = !current.camerasOnline
    val action = if (cameras) "Cámaras en línea" else "Cámaras fuera de servicio"
    return current.copy(camerasOnline = cameras, lastAction = action)
}

fun requestEmergencySupport(current: RoyalShieldUiState): RoyalShieldUiState {
    return current.copy(
        emergencyTriggered = true,
        lastAction = "Botón de pánico presionado"
    )
}

fun scheduleEscort(current: RoyalShieldUiState): RoyalShieldUiState {
    val newCount = current.escortRequests + 1
    return current.copy(
        escortRequests = newCount,
        lastAction = "Acompañamiento programado #$newCount"
    )
}

fun shareTrustedLocation(current: RoyalShieldUiState): RoyalShieldUiState {
    return current.copy(
        locationShared = true,
        lastAction = "Ubicación compartida con el círculo seguro"
    )
}

fun checkUrlSafety(current: RoyalShieldUiState): RoyalShieldUiState {
    val threats = current.urlThreatsBlocked + 1
    return current.copy(
        urlThreatsBlocked = threats,
        lastAction = "URL maliciosa bloqueada #$threats"
    )
}

fun toggleDataBreachMonitor(current: RoyalShieldUiState): RoyalShieldUiState {
    val monitoring = !current.dataBreachMonitoring
    val action = if (monitoring) {
        "Monitor de fugas activo"
    } else {
        "Monitor de fugas pausado"
    }
    return current.copy(dataBreachMonitoring = monitoring, lastAction = action)
}

fun runMalwareScanner(current: RoyalShieldUiState): RoyalShieldUiState {
    val running = !current.malwareScanRunning
    val action = if (running) "Escaneo de apps iniciado" else "Escaneo completado"
    return current.copy(malwareScanRunning = running, lastAction = action)
}

fun toggleSoundDetection(current: RoyalShieldUiState): RoyalShieldUiState {
    val enabled = !current.soundDetectionEnabled
    val action = if (enabled) "Detección acústica armada" else "Detección acústica detenida"
    return current.copy(soundDetectionEnabled = enabled, lastAction = action)
}

fun toggleLowBatteryProtocol(current: RoyalShieldUiState): RoyalShieldUiState {
    val enabled = !current.lowBatteryProtocolEnabled
    val action = if (enabled) "Modo batería baja automatizado" else "Modo batería baja desactivado"
    return current.copy(lowBatteryProtocolEnabled = enabled, lastAction = action)
}

fun toggleFakePin(current: RoyalShieldUiState): RoyalShieldUiState {
    val enabled = !current.fakePinEnabled
    val action = if (enabled) "PIN falso armado" else "PIN falso desarmado"
    return current.copy(fakePinEnabled = enabled, lastAction = action)
}

fun toggleVoiceAssistant(current: RoyalShieldUiState): RoyalShieldUiState {
    val listening = !current.voiceAssistantListening
    val action = if (listening) "Asistente de voz escuchando" else "Asistente de voz en espera"
    return current.copy(voiceAssistantListening = listening, lastAction = action)
}

fun toggleAutoRecording(current: RoyalShieldUiState): RoyalShieldUiState {
    val enabled = !current.autoRecordingEnabled
    val action = if (enabled) "Grabación automática armada" else "Grabación automática detenida"
    return current.copy(autoRecordingEnabled = enabled, lastAction = action)
}

fun toggleSafePathMonitoring(current: RoyalShieldUiState): RoyalShieldUiState {
    val enabled = !current.safePathMonitoring
    val action = if (enabled) "Ruta segura vigilada" else "Ruta segura finalizada"
    return current.copy(safePathMonitoring = enabled, lastAction = action)
}

@Composable
fun RoyalShieldScreen(modifier: Modifier = Modifier) {
    var uiState by rememberSaveable { mutableStateOf(RoyalShieldUiState()) }
    val gradient = Brush.verticalGradient(
        listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
            MaterialTheme.colorScheme.surface
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(gradient)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 36.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            RoyalShieldHeader(uiState)

            StatusCard(uiState)

            val actions = listOf(
                SecurityAction(
                    emoji = "🛡️",
                    title = if (uiState.alarmArmed) "Alarma activa" else "Activar alarma",
                    description = if (uiState.alarmArmed) "Todo el perímetro está protegido" else "Arma la red completa",
                    onClick = { uiState = toggleAlarm(uiState) }
                ),
                SecurityAction(
                    emoji = "🌙",
                    title = if (uiState.nightModeEnabled) "Modo nocturno activo" else "Activar modo nocturno",
                    description = if (uiState.nightModeEnabled) "Rutina nocturna automatizada" else "Atenúa luces y sensores",
                    onClick = { uiState = toggleNightMode(uiState) }
                ),
                SecurityAction(
                    emoji = "📹",
                    title = if (uiState.camerasOnline) "Cámaras en vivo" else "Reactivar cámaras",
                    description = if (uiState.camerasOnline) "Monitoreo transmitiendo" else "Vuelve a habilitar transmisión",
                    onClick = { uiState = toggleCameras(uiState) }
                ),
                SecurityAction(
                    emoji = "🚓",
                    title = "Pedir patrulla",
                    description = "Solicita acompañamiento preventivo",
                    onClick = { uiState = scheduleEscort(uiState) }
                )
            )

            ActionsGrid(actions = actions)

            EmergencyCard(
                lastAction = uiState.lastAction,
                emergencyTriggered = uiState.emergencyTriggered,
                locationShared = uiState.locationShared,
                escortRequests = uiState.escortRequests,
                onEmergency = { uiState = requestEmergencySupport(uiState) },
                onShareLocation = { uiState = shareTrustedLocation(uiState) }
            )

            AdvancedAutomationPanel(
                uiState = uiState,
                onCheckUrl = { uiState = checkUrlSafety(uiState) },
                onToggleDataBreach = { uiState = toggleDataBreachMonitor(uiState) },
                onMalwareScan = { uiState = runMalwareScanner(uiState) },
                onToggleSoundDetection = { uiState = toggleSoundDetection(uiState) },
                onToggleLowBattery = { uiState = toggleLowBatteryProtocol(uiState) },
                onToggleFakePin = { uiState = toggleFakePin(uiState) },
                onToggleVoiceAssistant = { uiState = toggleVoiceAssistant(uiState) },
                onToggleAutoRecording = { uiState = toggleAutoRecording(uiState) },
                onToggleSafePath = { uiState = toggleSafePathMonitoring(uiState) }
            )

            FeatureSection(
                title = "🔒 Current Features",
                features = currentFeatures
            )

            FeatureSection(
                title = "🌟 Upcoming Features",
                features = upcomingFeatures
            )
        }
    }
}

data class SubscriptionTier(
    val title: String,
    val price: String,
    val perks: List<String>,
    val accent: Color
)

@Composable
fun SubscriptionScreen(modifier: Modifier = Modifier) {
    val gold = Color(0xFFFFC107)
    val deepGold = Color(0xFFFFA000)
    val obsidian = Color(0xFF0E0E0E)
    val gradient = Brush.verticalGradient(listOf(obsidian, Color(0xFF1B1B1B), obsidian))
    var showWelcomePopup by rememberSaveable { mutableStateOf(true) }
    var showLimitedOffer by rememberSaveable { mutableStateOf(false) }

    val tiers = listOf(
        SubscriptionTier(
            title = "Elite Black",
            price = "USD 29.99 / mes",
            perks = listOf(
                "Inteligencia predictiva 24/7",
                "Canal directo con analistas Royal Shield",
                "Autodesbloqueo biométrico redundante"
            ),
            accent = deepGold
        ),
        SubscriptionTier(
            title = "Signature Gold",
            price = "USD 14.99 / mes",
            perks = listOf(
                "Escaneo avanzado de enlaces y malware",
                "Rutas seguras ilimitadas",
                "Backup cifrado en nube soberana"
            ),
            accent = gold
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(gradient)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "Royal Shield Elite",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = gold
            )
            Text(
                text = "Activa los protocolos más exclusivos con un diseño dorado y negro inspirado en los centros de mando de lujo.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFFEEEEEE)
            )

            ElevatedCard(
                shape = RoundedCornerShape(32.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF111111).copy(alpha = 0.85f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Funciones avanzadas",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = gold
                    )
                    val advancedOps = listOf(
                        "Firewall anti-phishing reforzado",
                        "Modo señuelo para secuestros digitales",
                        "Seguimiento satelital de escoltas",
                        "Análisis de audio con IA forense"
                    )
                    advancedOps.forEach { item ->
                        Text(text = "• $item", color = Color(0xFFDDDDDD))
                    }
                }
            }

            tiers.forEach { tier ->
                SubscriptionTierCard(
                    tier = tier,
                    onSubscribe = { showLimitedOffer = true }
                )
            }

            Button(
                onClick = { showLimitedOffer = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color.Black)
            ) {
                Text(text = "Desbloquear prueba VIP")
            }
        }

        if (showWelcomePopup) {
            PromoDialog(
                title = "Bienvenido a Royal Shield Elite",
                description = "Obtén 7 días de monitoreo completo agregando tu método de pago premium.",
                confirmLabel = "Activar ahora",
                onConfirm = {
                    showWelcomePopup = false
                    showLimitedOffer = true
                },
                onDismiss = { showWelcomePopup = false }
            )
        }

        if (showLimitedOffer) {
            PromoDialog(
                title = "Promo de lealtad",
                description = "Actualiza hoy y recibe monitoreo acústico y video AI ilimitado.",
                confirmLabel = "Aceptar oferta",
                onConfirm = { showLimitedOffer = false },
                onDismiss = { showLimitedOffer = false }
            )
        }
    }
}

@Composable
fun SubscriptionTierCard(tier: SubscriptionTier, onSubscribe: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF1A1A1A))
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = tier.title, color = tier.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(text = tier.price, color = Color.White.copy(alpha = 0.9f))
                }
                Button(onClick = onSubscribe) {
                    Text(text = "Suscribirme")
                }
            }
            tier.perks.forEach {
                Text(text = "• $it", color = Color(0xFFCCCCCC))
            }
        }
    }
}

@Composable
fun PromoDialog(
    title: String,
    description: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = title, fontWeight = FontWeight.Bold) },
        text = { Text(text = description) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(text = confirmLabel) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(text = "Más tarde") }
        }
    )
}

@Composable
fun RegistrationScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val firebaseAuth = remember { Firebase.auth }
    val webClientId = stringResource(id = R.string.firebase_web_client_id)
    var registrationStatus by rememberSaveable { mutableStateOf<String?>(null) }
    var isLoading by rememberSaveable { mutableStateOf(false) }

    val googleSignInOptions = remember(webClientId) {
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(webClientId)
            .requestEmail()
            .build()
    }
    val googleSignInClient = remember(googleSignInOptions) {
        GoogleSignIn.getClient(context, googleSignInOptions)
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)
            firebaseAuth.signInWithCredential(credential).addOnCompleteListener { authResult ->
                isLoading = false
                registrationStatus = if (authResult.isSuccessful) {
                    "Cuenta verificada: ${account.displayName ?: account.email}"
                } else {
                    "Error de autenticación: ${authResult.exception?.localizedMessage}".trim()
                }
            }
        } catch (error: ApiException) {
            isLoading = false
            registrationStatus = "No se pudo iniciar sesión con Google: ${error.statusCode}"
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Regístrate con Google",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Conecta Firebase Authentication para vincular tus credenciales de Google y sincronizar tu perfil Royal Shield.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
            Button(
                onClick = {
                    isLoading = true
                    registrationStatus = null
                    launcher.launch(googleSignInClient.signInIntent)
                },
                enabled = !isLoading,
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                Text(text = if (isLoading) "Conectando..." else "Continuar con Google")
            }
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(48.dp))
            }
            registrationStatus?.let { status ->
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Text(
                        text = status,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

data class SecurityAction(
    val emoji: String,
    val title: String,
    val description: String,
    val onClick: () -> Unit
)

data class FeatureDetail(
    val emoji: String,
    val title: String,
    val description: String
)

private val currentFeatures = listOf(
    FeatureDetail(
        emoji = "🧭",
        title = "Real-time location sharing",
        description = "Share your live position with emergency contacts."
    ),
    FeatureDetail(
        emoji = "🚨",
        title = "Motion-aware S.O.S.",
        description = "Panic button that can auto-trigger if the phone detects risk."
    ),
    FeatureDetail(
        emoji = "📸",
        title = "Emergency camera",
        description = "Instantly captures and sends photos or video evidence."
    )
)

private val upcomingFeatures = listOf(
    FeatureDetail("🌐", "URL checker", "Blocks suspicious links before you open them."),
    FeatureDetail("🔐", "Data breach monitor", "Alerts you if your email is compromised."),
    FeatureDetail("🧪", "Malware scanner", "Analyzes installed apps for malicious behavior."),
    FeatureDetail("🎤", "Sound detection", "Listens for screams or loud noises to trigger help."),
    FeatureDetail("🔋", "Low-battery safety", "Automatically sends location when charge < 15%."),
    FeatureDetail("🕵️", "Fake PIN alert", "Silent alarm if someone forces you to unlock."),
    FeatureDetail("🤖", "AI voice assistant", "Responds to commands like 'Help' during crises."),
    FeatureDetail("🎙️", "Automatic audio capture", "Records audio automatically in S.O.S. mode."),
    FeatureDetail("🛰️", "Safe path mode", "Warns you if you deviate from a trusted route.")
)

@Composable
fun RoyalShieldHeader(uiState: RoyalShieldUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Royal Shield",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimary
        )
        Text(
            text = if (uiState.alarmArmed) "Protección activa" else "Sistema en espera",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
        )
    }
}

@Composable
fun StatusCard(uiState: RoyalShieldUiState, modifier: Modifier = Modifier) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
        )
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Estado general",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                StatusBadge(
                    title = if (uiState.alarmArmed) "Armado" else "Desarmado",
                    value = if (uiState.alarmArmed) "Perímetro protegido" else "Listo para activar"
                )
                StatusBadge(
                    title = if (uiState.camerasOnline) "Cámaras" else "Sin cámaras",
                    value = if (uiState.camerasOnline) "Monitoreo en vivo" else "Revisa conexión"
                )
            }
            Text(
                text = uiState.lastAction,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun StatusBadge(title: String, value: String) {
    Column(
        modifier = Modifier.widthIn(min = 120.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun ActionsGrid(actions: List<SecurityAction>) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        actions.chunked(2).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                row.forEach { action ->
                    RoyalShieldActionCard(
                        action = action,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (row.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoyalShieldActionCard(action: SecurityAction, modifier: Modifier = Modifier) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        onClick = action.onClick
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(text = action.emoji, fontSize = 28.sp)
            Text(
                text = action.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = action.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun EmergencyCard(
    lastAction: String,
    emergencyTriggered: Boolean,
    locationShared: Boolean,
    escortRequests: Int,
    onEmergency: () -> Unit,
    onShareLocation: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Centro de emergencias",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (emergencyTriggered) "Alerta enviada al equipo" else "Listo para responder al instante",
                style = MaterialTheme.typography.bodyMedium
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onEmergency,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = if (emergencyTriggered) "Reforzar alerta" else "Botón de pánico")
                }
                OutlinedButton(
                    onClick = onShareLocation,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = if (locationShared) "Ubicación enviada" else "Compartir ubicación")
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Acompañamientos: $escortRequests",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = lastAction,
                    textAlign = TextAlign.End,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun AdvancedAutomationPanel(
    uiState: RoyalShieldUiState,
    onCheckUrl: () -> Unit,
    onToggleDataBreach: () -> Unit,
    onMalwareScan: () -> Unit,
    onToggleSoundDetection: () -> Unit,
    onToggleLowBattery: () -> Unit,
    onToggleFakePin: () -> Unit,
    onToggleVoiceAssistant: () -> Unit,
    onToggleAutoRecording: () -> Unit,
    onToggleSafePath: () -> Unit,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
        )
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Automatizaciones avanzadas",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Simula las funciones próximas directamente desde Android Studio.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            AutomationActionRow(
                emoji = "🌐",
                title = "URL checker",
                status = "Bloqueos: ${uiState.urlThreatsBlocked}",
                actionLabel = "Revisar enlace",
                onClick = onCheckUrl
            )
            AutomationActionRow(
                emoji = "🔐",
                title = "Data breach monitor",
                status = if (uiState.dataBreachMonitoring) "Vigilando filtraciones" else "Inactivo",
                actionLabel = if (uiState.dataBreachMonitoring) "Pausar" else "Activar",
                onClick = onToggleDataBreach
            )
            AutomationActionRow(
                emoji = "🧪",
                title = "App scanner",
                status = if (uiState.malwareScanRunning) "Escaneando" else "Listo",
                actionLabel = if (uiState.malwareScanRunning) "Detener" else "Escanear",
                onClick = onMalwareScan
            )
            AutomationActionRow(
                emoji = "🎤",
                title = "Detección de sonido",
                status = if (uiState.soundDetectionEnabled) "Escuchando" else "Apagado",
                actionLabel = if (uiState.soundDetectionEnabled) "Silenciar" else "Armar",
                onClick = onToggleSoundDetection
            )
            AutomationActionRow(
                emoji = "🔋",
                title = "Modo batería baja",
                status = if (uiState.lowBatteryProtocolEnabled) "Protocolo activo" else "Apagado",
                actionLabel = if (uiState.lowBatteryProtocolEnabled) "Desactivar" else "Activar",
                onClick = onToggleLowBattery
            )
            AutomationActionRow(
                emoji = "🕵️",
                title = "PIN falso",
                status = if (uiState.fakePinEnabled) "Listo" else "Sin configurar",
                actionLabel = if (uiState.fakePinEnabled) "Desarmar" else "Armar",
                onClick = onToggleFakePin
            )
            AutomationActionRow(
                emoji = "🤖",
                title = "Asistente de voz IA",
                status = if (uiState.voiceAssistantListening) "Escuchando 'Help'" else "Dormido",
                actionLabel = if (uiState.voiceAssistantListening) "Pausar" else "Escuchar",
                onClick = onToggleVoiceAssistant
            )
            AutomationActionRow(
                emoji = "🎙️",
                title = "Grabación automática",
                status = if (uiState.autoRecordingEnabled) "Grabando" else "Listo",
                actionLabel = if (uiState.autoRecordingEnabled) "Detener" else "Iniciar",
                onClick = onToggleAutoRecording
            )
            AutomationActionRow(
                emoji = "🛰️",
                title = "Ruta segura",
                status = if (uiState.safePathMonitoring) "Monitoreando" else "Inactivo",
                actionLabel = if (uiState.safePathMonitoring) "Terminar" else "Vigilar",
                onClick = onToggleSafePath
            )
        }
    }
}

@Composable
fun AutomationActionRow(
    emoji: String,
    title: String,
    status: String,
    actionLabel: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = "$emoji $title", fontWeight = FontWeight.SemiBold)
            Text(
                text = status,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Button(onClick = onClick) {
            Text(text = actionLabel)
        }
    }
}

@Composable
fun FeatureSection(title: String, features: List<FeatureDetail>, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onPrimary
        )
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            features.forEach { feature ->
                FeatureCard(feature = feature)
            }
        }
    }
}

@Composable
fun FeatureCard(feature: FeatureDetail, modifier: Modifier = Modifier) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = feature.emoji, fontSize = 24.sp)
            Text(
                text = feature.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = feature.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Preview(showSystemUi = true)
@Composable
fun RoyalShieldPreview() {
    Royal_shieldTheme {
        RoyalShieldApp()
    }
}
