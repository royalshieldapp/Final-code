package com.royalshield.app

import android.content.Context
import android.webkit.JavascriptInterface
import android.widget.Toast

/**
 * "Puente" para comunicar JavaScript en el WebView con el código nativo de Android.
 */
class WebAppInterface(private val context: Context) {

    /** Muestra un mensaje Toast desde la web. */
    @JavascriptInterface
    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    /**
     * Activa la secuencia de S.O.S.
     * Aquí es donde agregarías la lógica para enviar la ubicación, grabar video, etc.
     */
    @JavascriptInterface
    fun triggerSos() {
        // Por ahora, solo mostramos un mensaje para confirmar que funciona.
        showToast("S.O.S. sequence activated!")
    }

    /**
     * Analiza una URL en busca de amenazas.
     * Aquí es donde te conectarías a tu backend de VirusTotal.
     */
    @JavascriptInterface
    fun checkUrl(url: String) {
        // Por ahora, solo mostramos la URL para confirmar que funciona.
        showToast("Checking URL: $url")
    }
}