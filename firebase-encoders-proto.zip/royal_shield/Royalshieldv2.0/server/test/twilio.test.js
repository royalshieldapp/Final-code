import { test, mock } from "node:test";
import assert from "node:assert/strict";

const baseUrl = "https://api.twilio.com/2010-04-01/Accounts";

function buildResponse(ok, payload) {
  return {
    ok,
    async json() {
      return payload;
    },
  };
}

test("sendSOS uses the messaging service SID when provided", async () => {
  const fetchStub = mock.fn(async (url, options) => {
    assert.equal(url, `${baseUrl}/AC123/Messages.json`);
    assert.equal(options.method, "POST");
    assert.equal(
      options.headers.Authorization,
      `Basic ${Buffer.from("AC123:token").toString("base64")}`
    );

    const params = new URLSearchParams(options.body);
    assert.equal(params.get("To"), "+15551234");
    assert.equal(params.get("MessagingServiceSid"), "MG999");
    assert.equal(params.get("From"), null);
    assert.equal(params.get("Body"), "hello");

    return buildResponse(true, { sid: "SM1", status: "queued" });
  });

  const { sendSOS } = await import("../src/twilio.js");

  const result = await sendSOS("+15551234", "hello", {
    accountSid: "AC123",
    authToken: "token",
    messagingServiceSid: "MG999",
    fetch: fetchStub,
  });

  assert.deepEqual(result, { ok: true, to: "+15551234", sid: "SM1", status: "queued" });
  assert.equal(fetchStub.mock.callCount(), 1);
});

test("sendSOS falls back to the From number and surfaces API errors", async () => {
  const fetchStub = mock.fn(async (url, options) => {
    assert.equal(url, `${baseUrl}/AC555/Messages.json`);

    const params = new URLSearchParams(options.body);
    assert.equal(params.get("MessagingServiceSid"), null);
    assert.equal(params.get("From"), "+18885551234");

    return buildResponse(false, { message: "twilio error message" });
  });

  const { sendSOS } = await import("../src/twilio.js");

  const result = await sendSOS("+19998887777", "danger", {
    accountSid: "AC555",
    authToken: "auth-token",
    from: "+18885551234",
    fetch: fetchStub,
  });

  assert.deepEqual(result, {
    ok: false,
    to: "+19998887777",
    error: "twilio error message",
  });
  assert.equal(fetchStub.mock.callCount(), 1);
});

test("sendSOS throws when required credentials are missing", async () => {
  const { sendSOS } = await import("../src/twilio.js");

  await assert.rejects(
    () =>
      sendSOS("+12223334444", "hi", {
        fetch: async () => buildResponse(true, { sid: "SM1", status: "queued" }),
      }),
    /Twilio env vars missing/
  );
});
