import { test, mock } from "node:test";
import assert from "node:assert/strict";

const baseUrl = "https://www.virustotal.com/api/v3";

function buildResponse(ok, payload) {
  return {
    ok,
    async json() {
      return payload;
    },
  };
}

test("submitUrlForScan sends the URL with the provided API key", async () => {
  const fetchStub = mock.fn(async (url, options) => {
    assert.equal(url, `${baseUrl}/urls`);
    assert.equal(options.method, "POST");
    assert.equal(options.headers["x-apikey"], "test-key");
    assert.equal(
      options.headers["Content-Type"],
      "application/x-www-form-urlencoded"
    );
    assert.equal(options.body, "url=https%3A%2F%2Fexample.com");

    return buildResponse(true, { data: { id: "analysis-id" } });
  });

  const { submitUrlForScan } = await import("../src/virustotal.js");

  const id = await submitUrlForScan("https://example.com", {
    apiKey: "test-key",
    fetch: fetchStub,
  });

  assert.equal(id, "analysis-id");
  assert.equal(fetchStub.mock.callCount(), 1);
});

test("getAnalysis retrieves the analysis payload", async () => {
  const fetchStub = mock.fn(async (url, options) => {
    assert.equal(url, `${baseUrl}/analyses/abc`);
    assert.equal(options.headers["x-apikey"], "test-key");
    return buildResponse(true, { data: { attributes: { status: "completed" } } });
  });

  const { getAnalysis } = await import("../src/virustotal.js");

  const data = await getAnalysis("abc", { apiKey: "test-key", fetch: fetchStub });
  assert.equal(data.data.attributes.status, "completed");
  assert.equal(fetchStub.mock.callCount(), 1);
});

test("getDomainReport returns the domain information", async () => {
  const fetchStub = mock.fn(async (url, options) => {
    assert.equal(url, `${baseUrl}/domains/example.com`);
    assert.equal(options.headers["x-apikey"], "test-key");
    return buildResponse(true, { data: { id: "example.com" } });
  });

  const { getDomainReport } = await import("../src/virustotal.js");

  const data = await getDomainReport("example.com", {
    apiKey: "test-key",
    fetch: fetchStub,
  });

  assert.equal(data.data.id, "example.com");
  assert.equal(fetchStub.mock.callCount(), 1);
});

test("submitUrlForScan throws when the API returns an error", async () => {
  const fetchStub = mock.fn(async () =>
    buildResponse(false, { error: { message: "vt error" } })
  );

  const { submitUrlForScan } = await import("../src/virustotal.js");

  await assert.rejects(
    () =>
      submitUrlForScan("https://bad.example", {
        apiKey: "test-key",
        fetch: fetchStub,
      }),
    /vt error/
  );
});

test("VirusTotal helpers throw when the API key is missing", async () => {
  const { submitUrlForScan, getAnalysis, getDomainReport } = await import(
    "../src/virustotal.js"
  );

  await assert.rejects(
    () => submitUrlForScan("https://example.com", { fetch: async () => buildResponse(true, {}) }),
    /VT_API_KEY missing/
  );

  await assert.rejects(
    () => getAnalysis("abc", { fetch: async () => buildResponse(true, {}) }),
    /VT_API_KEY missing/
  );

  await assert.rejects(
    () => getDomainReport("example.com", { fetch: async () => buildResponse(true, {}) }),
    /VT_API_KEY missing/
  );
});
