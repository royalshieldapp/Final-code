import fetch from "node-fetch";

const VT = "https://www.virustotal.com/api/v3";

function getApiKey(overrides = {}) {
  return overrides.apiKey ?? process.env.VT_API_KEY;
}

function vtHeaders(overrides = {}, extra = {}) {
  const apiKey = getApiKey(overrides);
  if (!apiKey) throw new Error("VT_API_KEY missing");
  return { "x-apikey": apiKey, ...extra };
}

// Submit a URL for scanning (returns analysis id)
export async function submitUrlForScan(url, overrides = {}) {
  const body = new URLSearchParams();
  body.set("url", url);

  const fetchImpl = overrides.fetch ?? fetch;
  const r = await fetchImpl(`${VT}/urls`, {
    method: "POST",
    headers: vtHeaders(overrides, {
      "Content-Type": "application/x-www-form-urlencoded",
    }),
    body: body.toString(),
  });

  const data = await r.json();
  if (!r.ok) throw new Error(data?.error?.message || "VT submit error");
  return data.data.id;
}

// Poll analysis result
export async function getAnalysis(id, overrides = {}) {
  const fetchImpl = overrides.fetch ?? fetch;
  const r = await fetchImpl(`${VT}/analyses/${encodeURIComponent(id)}`, {
    headers: vtHeaders(overrides),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data?.error?.message || "VT analysis error");
  return data;
}

// Domain report
export async function getDomainReport(host, overrides = {}) {
  const fetchImpl = overrides.fetch ?? fetch;
  const r = await fetchImpl(`${VT}/domains/${encodeURIComponent(host)}`, {
    headers: vtHeaders(overrides),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data?.error?.message || "VT domain error");
  return data;
}
