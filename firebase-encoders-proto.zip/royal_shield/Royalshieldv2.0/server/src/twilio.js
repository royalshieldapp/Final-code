import fetch from "node-fetch";

function resolveTwilioConfig(overrides = {}) {
  const env = process.env;
  return {
    accountSid: overrides.accountSid ?? env.TWILIO_ACCOUNT_SID,
    authToken: overrides.authToken ?? env.TWILIO_AUTH_TOKEN,
    from: overrides.from ?? env.TWILIO_FROM,
    messagingServiceSid:
      overrides.messagingServiceSid ?? env.TWILIO_MESSAGING_SERVICE_SID,
    fetchImpl: overrides.fetch ?? fetch,
  };
}

/**
 * Send an SMS with Twilio Messages API.
 * @param {string} to - destination number e.g. +15551234567
 * @param {string} body - message body
 * @param {object} [overrides] - dependency injection for tests/configuration
 */
export async function sendSOS(to, body, overrides = {}) {
  const { accountSid, authToken, from, messagingServiceSid, fetchImpl } =
    resolveTwilioConfig(overrides);

  if (!accountSid || !authToken || (!from && !messagingServiceSid)) {
    throw new Error("Twilio env vars missing");
  }

  const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
  const params = new URLSearchParams();
  params.set("To", to);
  if (messagingServiceSid) {
    params.set("MessagingServiceSid", messagingServiceSid);
  } else {
    params.set("From", from);
  }
  params.set("Body", body);

  const auth = Buffer.from(`${accountSid}:${authToken}`).toString("base64");
  const r = await fetchImpl(url, {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: params.toString(),
  });

  const data = await r.json();
  if (!r.ok) {
    return { ok: false, to, error: data?.message || "twilio error" };
  }

  return { ok: true, to, sid: data.sid, status: data.status };
}
