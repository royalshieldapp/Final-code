import "dotenv/config";
import express from "express";
import cors from "cors";
import { sendSOS } from "./twilio.js";
import { submitUrlForScan, getAnalysis, getDomainReport } from "./virustotal.js";

const app = express();
app.use(cors());
app.use(express.json());

// Health
app.get("/api/health", (_req, res) => res.json({ ok: true, service: "royal-shield" }));

// === SOS via Twilio =========================================================
/**
 * POST /api/sos
 * Body:
 * {
 *   "to": ["+15551234567","+15557654321"], // 1..N recipients
 *   "note": "Emergency, I need help",
 *   "lat": 37.4219983, // optional
 *   "lng": -122.084, // optional
 *   "accuracy": 8 // optional (meters)
 * }
 */
app.post("/api/sos", async (req, res) => {
  try {
    const { to, note, lat, lng, accuracy } = req.body || {};

    if (!Array.isArray(to) || to.length === 0) {
      return res.status(400).json({ ok: false, error: "`to` must be a non-empty array" });
    }

    const link = lat && lng ? `https://maps.google.com/?q=${lat},${lng}` : "";
    const acc = accuracy || accuracy === 0 ? ` (±${Math.round(accuracy)} m)` : "";
    const text = `${note || "I NEED HELP"}. ${link ? `My location: ${link}${acc}` : ""}`.trim();

    const results = [];
    for (const num of to) {
      // send one-by-one for clearer per-recipient status
      // eslint-disable-next-line no-await-in-loop
      results.push(await sendSOS(num, text));
    }

    res.json({ ok: true, results });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: "Internal error" });
  }
});

// === VirusTotal: URL scanning ===============================================
/**
 * POST /api/scan-url { "url": "https://site.com" }
 * -> { ok, id, status: "submitted" }
 */
app.post("/api/scan-url", async (req, res) => {
  try {
    const { url } = req.body || {};
    if (!url) return res.status(400).json({ ok: false, error: "url required" });

    const id = await submitUrlForScan(url);
    res.json({ ok: true, id, status: "submitted" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: "Internal error" });
  }
});

/**
 * GET /api/scan-url/:id -> analysis status/result
 */
app.get("/api/scan-url/:id", async (req, res) => {
  try {
    const data = await getAnalysis(req.params.id);
    res.json({ ok: true, data });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: "Internal error" });
  }
});

/**
 * GET /api/domain/:host -> domain report
 */
app.get("/api/domain/:host", async (req, res) => {
  try {
    const data = await getDomainReport(req.params.host);
    res.json({ ok: true, data });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: "Internal error" });
  }
});

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Royal Shield backend running on :${port}`));
