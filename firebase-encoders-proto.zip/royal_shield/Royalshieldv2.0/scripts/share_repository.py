"""Utility for packaging a repository into a ZIP archive for sharing."""
from __future__ import annotations

import argparse
import datetime as _dt
import sys
from pathlib import Path
from typing import Iterable, Set

DEFAULT_EXCLUDES = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".venv",
    "node_modules",
}


def _parse_args(argv: Iterable[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create a ZIP archive of a repository for sharing.",
    )
    parser.add_argument(
        "source",
        type=Path,
        help="Path to the repository directory that should be packaged.",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        help="Optional path for the resulting ZIP archive. Defaults to <repo>-<timestamp>.zip",
    )
    parser.add_argument(
        "-x",
        "--exclude",
        action="append",
        default=[],
        help=(
            "Additional directories or file name patterns to exclude. "
            "The option can be provided multiple times."
        ),
    )
    return parser.parse_args(list(argv))


def _build_exclude_set(additional: Iterable[str]) -> Set[str]:
    excludes: Set[str] = set(DEFAULT_EXCLUDES)
    excludes.update(Path(item).parts[0] for item in additional if item)
    return excludes


def _resolve_output_path(source: Path, requested_output: Path | None) -> Path:
    if requested_output:
        return requested_output

    timestamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    return source.with_name(f"{source.name}-{timestamp}.zip")


def _should_exclude(path: Path, excludes: Set[str]) -> bool:
    return any(part in excludes for part in path.parts)


def create_archive(source: Path, output: Path, excludes: Iterable[str]) -> Path:
    """Create a ZIP archive containing the repository contents."""
    from zipfile import ZIP_DEFLATED, ZipFile

    if not source.exists() or not source.is_dir():
        raise ValueError(f"Source directory '{source}' does not exist or is not a directory.")

    exclude_set = _build_exclude_set(excludes)
    resolved_output = output

    with ZipFile(resolved_output, "w", compression=ZIP_DEFLATED) as archive:
        for path in sorted(source.rglob("*")):
            if not path.is_file():
                continue

            relative_path = path.relative_to(source)
            if _should_exclude(relative_path, exclude_set):
                continue

            archive.write(path, arcname=str(relative_path))

    return resolved_output


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv or sys.argv[1:])
    source = args.source.resolve()
    output = _resolve_output_path(source, args.output)

    try:
        created = create_archive(source, output, args.exclude)
    except ValueError as exc:
        print(exc, file=sys.stderr)
        return 1

    print(f"Created archive: {created}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
