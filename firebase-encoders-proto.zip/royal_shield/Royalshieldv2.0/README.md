# Royalshieldv2.0

Reconstruction of a new app.

## Sharing the repository

Use the helper script in `scripts/share_repository.py` to bundle the repository into a ZIP
archive that can be shared with collaborators.

```bash
python scripts/share_repository.py .
```

By default the archive will exclude common cache directories (for example `.git`,
`__pycache__`, and `node_modules`) and will be created alongside the repository using a
timestamped filename. You can customise the output location or exclusions:

```bash
python scripts/share_repository.py . --output /tmp/royalshield.zip --exclude dist --exclude build
```

## Royal Shield backend API

A lightweight Express server powers SMS alerts via Twilio and VirusTotal lookups. Configure it with the environment variables shown in `server/.env.example` and run the service with:

```bash
cd server
npm install
npm run dev
```

Endpoints are documented in `openapi.yaml` for easy import into API clients or Codex+.

### Twilio setup & verification

1. Create a Messaging Service in the [Twilio Console](https://console.twilio.com/) or note the phone number you want to send from.
2. Populate the following variables in `server/.env`:
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - Either `TWILIO_MESSAGING_SERVICE_SID` (recommended) **or** `TWILIO_FROM` with a verified number.
3. Restart the backend so it picks up the new environment variables.

You can validate the credentials with the raw REST API before wiring it to the app:

```bash
curl "https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json" \
  -X POST \
  --data-urlencode "To=+15616633069" \
  --data-urlencode "MessagingServiceSid=${TWILIO_MESSAGING_SERVICE_SID}" \
  --data-urlencode "Body=Ahoy 👋" \
  -u "${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}"
```

A successful response returns HTTP `201` and includes the message SID plus delivery status:

```json
{
  "sid": "SMXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  "status": "accepted",
  "to": "+15616633069",
  "messaging_service_sid": "MGXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
}
```

### VirusTotal setup & verification

1. Capture your VirusTotal API key and populate `VT_API_KEY` in `server/.env`. The team key currently in use is `3cd1d5a5366bba50820fb23a1a254734276768056811d25cf04c592ad6d93387`.
2. Restart the backend server so it loads the environment variable.
3. Submit a smoke scan with cURL to ensure the credential works:

```bash
curl -X POST https://www.virustotal.com/api/v3/urls \
  -H "x-apikey: ${VT_API_KEY}" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  --data-urlencode "url=https://example.com"
```

The API will return a JSON document containing an `data.id` analysis identifier. Poll it through the backend with:

```bash
curl "http://localhost:8080/api/scan-url/${ANALYSIS_ID}"
```
